 // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyDyGhpAYOz8Ege8F4tFgx8d-1mZwiz6JHY",
    authDomain: "mauwauwau-1294d.firebaseapp.com",
    projectId: "mauwauwau-1294d",
    storageBucket: "mauwauwau-1294d.appspot.com",
    messagingSenderId: "988214810295",
    appId: "1:988214810295:web:b61a02b6f15295332cdf32",
    measurementId: "G-6QSMQV8BH5"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  let db = firebase.firestore();

//Logear con Google
function regGoogle(provider) {
  var provider = new firebase.auth.GoogleAuthProvider();
  // [START auth_google_signin_popup]
  firebase.auth()
    .signInWithPopup(provider)
    .then((result) => {
      /** @type {firebase.auth.OAuthCredential} */
      var credential = result.credential;

      // This gives you a Google Access Token. You can use it to access the Google API.
      var token = credential.accessToken;
      // The signed-in user info.
      var user = result.user;
      //al entrar
      game.style.display="block";
      entrar.style.display="none";
      botn.style.display="none";
      maboz.style.display="none"
      // ...
    }).catch((error) => {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      // The email of the user's account used.
      var email = error.email;
      // The firebase.auth.AuthCredential type that was used.
      var credential = error.credential;
      // ...
    });
}

function RegGoogle(provider) {
  var provider = new firebase.auth.GoogleAuthProvider();
  // [START auth_google_signin_popup]
  firebase.auth()
    .signInWithPopup(provider)
    .then((result) => {
      /** @type {firebase.auth.OAuthCredential} */
      var credential = result.credential;

      // This gives you a Google Access Token. You can use it to access the Google API.
      var token = credential.accessToken;
      // The signed-in user info.
      var user = result.user;
      //al entrar
      mabox.style.display="block"
      entrar.style.display="none";
      botn.style.display="block"
      maboz.style.display="block"
      // ...
    }).catch((error) => {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      // The email of the user's account used.
      var email = error.email;
      // The firebase.auth.AuthCredential type that was used.
      var credential = error.credential;
      // ...
    });
}

let entrar=
document.querySelector(".form-login");
let dat=
document.querySelector(".form-db");
let game= 
document.querySelector(".form-game");
let mabox=
document.querySelector(".form-map");
let info=
document.querySelector(".form-info");
let botn = 
document.querySelector(".bttn");
let titulo=
document.querySelector(".maboz");
let score=
document.querySelector(".score");

function TScore(){
score;
}

//Observador
function Obs() {
// [START auth_state_listener]
firebase.auth().onAuthStateChanged((user) => {
  if (user) {
    // User is signed in, see docs for a list of available properties
    // https://firebase.google.com/docs/reference/js/firebase.User
    var uid = user.uid;
    //console.log(uid);
    //console.log(user);
    // ...
  } else {
    // User is signed out
    // ...
  }
});
// [END auth_state_listener]
}
Obs();
function salir() {
// [START auth_sign_out]
firebase.auth().signOut().then(() => {
  // Sign-out successful.
  entrar.style.display="block";
  game.style.display="none";
  dat.style.display="none";
  mabox.style.display="none";
  botn.style.display="none";
  maboz.style.display="none";
}).catch((error) => {
  // An error happened.
});
// [END auth_sign_out]
}
function database(){
game.style.display="none";
dat.style.display="block";

}

function datos(){
entrar.style.display="none";
info.style.display="block";
}

function login(){
entrar.style.display="block";
info.style.display="none";
}

function salirg(){
  // [START auth_sign_out]
  firebase.auth().signOut().then(() => {
    // Sign-out successful.
    entrar.style.display="block";
    game.style.display="none";
    dat.style.display="none";
    mabox.style.display="none";
    botn.style.display="none";
    maboz.style.display="none";
  }).catch((error) => {
    // An error happened.
  });
  // [END auth_sign_out]
}

// Añadir, Editar y Borrar
const taskForm = document.getElementById("task-form");
const taskScore = document.getElementById("task-score");
const tasksContainer = document.getElementById("tasks-container");
let editStatus = false;
let id = '';
/**
* Save a New Task in Firestore
* @param {string} name the title of the Task
* @param {string} country the description of the Task
*/
const saveTask = (name, score, country) =>
db.collection("Hola").doc().set({
  name,
  score,
  country,
});
let getTasks = () => db
.collection("Hola")
.orderBy("score", "desc")
.get();
let onGetTasks = (callback) => db.collection("Hola").onSnapshot(callback);
let getTask = (id) => db.collection("Hola").doc(id).get();
window.addEventListener("DOMContentLoaded", async (e) => {
onGetTasks((querySnapshot) => {
  tasksContainer.innerHTML = "";
  querySnapshot.forEach((doc) => {
    var task = doc.data();
    tasksContainer.innerHTML += `<div class="card card-body mt-2">
  <h3 class="h5">${task.name}</h3>
  <p>${task.score}</p>
  <p>${task.country}</p>
  
</div>`;
  });
});
});
taskForm.addEventListener("submit", async (e) => {
e.preventDefault();
const name = taskForm["task-title"];
const score = taskForm["task-score"];
const country = taskForm["task-description"];
try {
  if (!editStatus) {
    await saveTask(name.value, score.value, country.value);
  } else {

    taskForm['btn-task-form'].innerText = 'Añadir';
  }
  taskForm.reset();
  name.focus();
} catch (error) {
  console.log(error);
}
});